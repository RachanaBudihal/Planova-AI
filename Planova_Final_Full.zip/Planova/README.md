
# Planova
## Intelligent Demand, Inventory & Supply Planning System

### 1. Project Overview
Planova is a data-driven planning system designed to connect
demand forecasting, inventory management and supplier planning.
It identifies potential shortages and helps users explore
possible mitigation options.

### 2. Main Features
- SKU, location and supplier master datasets
- Demand and inventory data generation
- Purchase order and supplier lead-time tracking
- Supplier capacity information
- Shortage identification
- Mitigation option generation
- Edge case test scenarios
- Data validation and data dictionary

### 3. Technologies Used
- Python
- Pandas
- NumPy
- Plotly
- Google Colab

### 4. Dataset Information
The project generates sample datasets using a fixed random seed:
20261022.

The current prototype uses a smaller dataset for development
and testing.

### 5. Project Files
All generated CSV files are stored in the data folder.

Important files include:
- skus.csv
- locations.csv
- suppliers.csv
- inventory.csv
- demand.csv
- purchase_orders.csv
- lead_times.csv
- supplier_capacity.csv
- ground_truth.csv
- edge_case_test_results.csv
- validation_summary.csv
- data_dictionary.csv

### 6. Execution
Open Planova.ipynb in Google Colab.
Run the notebook cells in order, starting with the imports
and dataset generation.

### 7. Reproducibility
The fixed random seed is 20261022.
Using the same seed and configuration supports reproducible
sample data generation.

### 8. Current Development Status
This is a development prototype. Integration, comprehensive
validation and dashboard development are ongoing.
